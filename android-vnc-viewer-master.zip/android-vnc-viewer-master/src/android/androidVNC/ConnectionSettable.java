/**
 * 
 */
package android.androidVNC;

/**
 * @author mike
 *
 */
interface ConnectionSettable {
	void setConnection(ConnectionBean connection);
}
